# Deer Hunting App

Files included:
- `deer-hunting-app.html` — browser-ready single-file app based on your JSX file
- `deer-hunting-tracker.jsx` — original source file you uploaded

How to use:
1. Open `deer-hunting-app.html` in Chrome, Safari, or Edge.
2. The app runs entirely in the browser.
3. Trail-cam AI analysis will run in mock mode unless you set an Anthropic API key in localStorage under `anthropic_api_key`.

To set an API key in the browser console:
```js
localStorage.setItem('anthropic_api_key', 'YOUR_KEY_HERE')
```
Then refresh the page.